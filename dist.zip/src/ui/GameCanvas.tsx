import { useEffect, useRef, useState } from 'react';
import { GameEngine } from '../game/GameEngine';

export function GameCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  
  const [hasStarted, setHasStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState<number>(() => {
    return Number(localStorage.getItem('pirate_battle_highscore') || '0');
  });
  const [health, setHealth] = useState(100);
  const [timeLeft, setTimeLeft] = useState(60);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        if (engineRef.current && hasStarted && !isGameOver) {
          engineRef.current.togglePause();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [hasStarted, isGameOver]);

  const startGame = () => {
    setHasStarted(true);
    const container = containerRef.current;
    if (!container) return;

    if (!engineRef.current) {
      const engine = new GameEngine();
      engineRef.current = engine;
      
      engine.init(container, (newScore, newHealth, newTime, gameOverFlag, pausedFlag, currentHighScore) => {
        setScore(newScore);
        setHealth(newHealth);
        setTimeLeft(newTime);
        setIsGameOver(gameOverFlag);
        setIsPaused(pausedFlag);
        setHighScore(currentHighScore);
      });
    } else {
      engineRef.current.restart();
    }
  };

  const handleRestart = () => {
    if (engineRef.current) {
      engineRef.current.audio.playClick();
      engineRef.current.restart();
    }
  };

  const handleReturnToMenu = () => {
    if (engineRef.current) {
      engineRef.current.audio.playClick();
      engineRef.current.restart();
    }
    setHasStarted(false);
    setIsGameOver(false);
    setIsPaused(false);
  };

  const handleTogglePause = () => {
    if (engineRef.current) {
      engineRef.current.togglePause();
    }
  };

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden', backgroundColor: '#001a33' }}>
      
      {/* 1. MENU INICIAL */}
      {!hasStarted && (
        <div style={{
          position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: '#001a33', zIndex: 30,
          display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
          color: 'white', fontFamily: 'monospace'
        }}>
          <h1 style={{ fontSize: '4rem', color: '#ffb703', textShadow: '4px 4px 0 #000', margin: '0 0 10px 0' }}>🏴‍☠️ PIRATE BATTLE</h1>
          <p style={{ fontSize: '1.2rem', color: '#8ecae6', marginBottom: '15px' }}>Sobreviva aos ataques nas águas da fortaleza!</p>
          
          <h3 style={{ fontSize: '1.5rem', color: '#ffb703', textShadow: '2px 2px 0 #000', margin: '0 0 30px 0' }}>
            🏆 Recorde Pessoal: {highScore}
          </h3>

          <button 
            onClick={startGame}
            style={{
              padding: '18px 45px', fontSize: '1.8rem', fontWeight: 'bold', cursor: 'pointer',
              backgroundColor: '#ffb703', color: '#000', border: '3px solid #fff', borderRadius: '12px',
              boxShadow: '0 6px 15px rgba(0,0,0,0.5)', transition: 'transform 0.1s'
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
            onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          >
            Iniciar Batalha
          </button>

          <div style={{ marginTop: '40px', fontSize: '1.1rem', color: '#aaa', textAlign: 'center' }}>
            <p style={{ margin: '6px 0', color: '#fff' }}>W, A, S, D — Navegação</p>
            <p style={{ margin: '6px 0', color: '#ffb703' }}>ESPAÇO — Tiro Frontal</p>
            <p style={{ margin: '6px 0', color: '#4caf50' }}>Q / E — Tiros Laterais (Bordadas Esquerda / Direita)</p>
            <p style={{ margin: '6px 0', color: '#8ecae6' }}>P / ESC — Pausa</p>
          </div>
        </div>
      )}

      {/* 2. HUD SUPERIOR EM JOGO */}
      {hasStarted && (
        <div style={{
          position: 'absolute', top: 20, left: 20, color: 'white', zIndex: 10,
          fontFamily: 'monospace', textShadow: '2px 2px 0 #000', pointerEvents: 'none'
        }}>
          <h2 style={{ margin: '5px 0' }}>🏆 Score: {score} <span style={{ fontSize: '1rem', color: '#ffb703' }}>(Recorde: {highScore})</span></h2>
          <h2 style={{ margin: '5px 0', color: health <= 30 ? '#ff4444' : 'white' }}>❤️ Health: {health}</h2>
          <h2 style={{ margin: '5px 0', color: timeLeft <= 10 ? '#ff4444' : 'white' }}>⏱️ Time: {timeLeft}s</h2>
        </div>
      )}

      {/* Botão de Pausa Manual */}
      {hasStarted && !isGameOver && (
        <button
          onClick={handleTogglePause}
          style={{
            position: 'absolute', top: 20, right: 20, zIndex: 15,
            padding: '10px 20px', fontSize: '1.2rem', fontFamily: 'monospace', fontWeight: 'bold',
            backgroundColor: '#023e8a', color: 'white', border: '2px solid #fff', borderRadius: '8px',
            cursor: 'pointer', boxShadow: '0 4px 10px rgba(0,0,0,0.4)'
          }}
        >
          {isPaused ? '▶ Continuar' : '⏸ Pausa'}
        </button>
      )}

      {/* 3. MENU DE PAUSA */}
      {isPaused && (
        <div style={{
          position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.65)', zIndex: 20,
          display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
          color: 'white', fontFamily: 'monospace', backdropFilter: 'blur(3px)'
        }}>
          <h1 style={{ fontSize: '4rem', color: '#8ecae6', textShadow: '4px 4px 0 #000', margin: '0 0 20px 0' }}>JOGO PAUSADO</h1>
          
          <button 
            onClick={handleTogglePause}
            style={{
              padding: '12px 35px', fontSize: '1.5rem', fontWeight: 'bold', cursor: 'pointer',
              backgroundColor: '#2196F3', color: 'white', border: '2px solid #fff', borderRadius: '10px',
              margin: '10px 0', width: '260px'
            }}
          >
            Continuar (P)
          </button>

          <button 
            onClick={handleRestart}
            style={{
              padding: '12px 35px', fontSize: '1.5rem', fontWeight: 'bold', cursor: 'pointer',
              backgroundColor: '#f44336', color: 'white', border: '2px solid #fff', borderRadius: '10px',
              margin: '10px 0', width: '260px'
            }}
          >
            Reiniciar
          </button>

          <button 
            onClick={handleReturnToMenu}
            style={{
              padding: '12px 35px', fontSize: '1.5rem', fontWeight: 'bold', cursor: 'pointer',
              backgroundColor: '#023e8a', color: 'white', border: '2px solid #fff', borderRadius: '10px',
              margin: '10px 0', width: '260px'
            }}
          >
            Voltar ao Menu
          </button>
        </div>
      )}

      {/* 4. TELA DE GAME OVER */}
      {isGameOver && (
        <div style={{
          position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.8)', zIndex: 20,
          display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
          color: 'white', fontFamily: 'monospace', backdropFilter: 'blur(4px)'
        }}>
          <h1 style={{ fontSize: '5rem', color: '#ff4444', textShadow: '4px 4px 0 #000', margin: '0 0 10px 0' }}>GAME OVER</h1>
          <h2 style={{ fontSize: '2.2rem', margin: '0 0 5px 0', textShadow: '2px 2px 0 #000' }}>Navios Destruídos: {score}</h2>
          <h3 style={{ fontSize: '1.5rem', color: '#ffb703', margin: '0 0 35px 0' }}>Melhor Pontuação: {highScore}</h3>
          
          <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap', justifyContent: 'center' }}>
            <button 
              onClick={handleRestart}
              style={{
                padding: '15px 35px', fontSize: '1.6rem', fontWeight: 'bold', cursor: 'pointer',
                backgroundColor: '#4CAF50', color: 'white', border: '3px solid #fff', borderRadius: '12px',
                boxShadow: '0 6px 15px rgba(0,0,0,0.5)', transition: 'transform 0.1s'
              }}
              onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
              onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
            >
              Tentar Novamente
            </button>

            <button 
              onClick={handleReturnToMenu}
              style={{
                padding: '15px 35px', fontSize: '1.6rem', fontWeight: 'bold', cursor: 'pointer',
                backgroundColor: '#023e8a', color: 'white', border: '3px solid #fff', borderRadius: '12px',
                boxShadow: '0 6px 15px rgba(0,0,0,0.5)', transition: 'transform 0.1s'
              }}
              onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
              onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
            >
              Voltar ao Menu
            </button>
          </div>
        </div>
      )}

      {/* Contentor Canvas do PixiJS */}
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
    </div>
  );
}