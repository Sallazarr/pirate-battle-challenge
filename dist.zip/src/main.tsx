import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { GameCanvas } from './ui/GameCanvas';

// Removemos as margens padrão do navegador para o canvas ocupar o ecrã inteiro
document.body.style.margin = '0';
document.body.style.padding = '0';
document.body.style.overflow = 'hidden';
document.body.style.backgroundColor = '#000';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GameCanvas />
  </StrictMode>,
);